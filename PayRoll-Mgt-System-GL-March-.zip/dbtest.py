from employee import SalaryCalculator

sc = SalaryCalculator()

sc.salarycalculation(eid = 1)